import UIKit

var greeting: String? = "Hello"

if greeting != nil {
    print(greeting!)
}

// Optional Binding
if let greetingValue = greeting {
    print(greetingValue)
}

struct Person {
    var name: String?
    
    func walk() {
        
    }
}

// Optional work with structures too
var me: Person? = nil

// Checking for nil before unwrapping and using instance
if me != nil {
    me!.walk()
}

// Optional Chaining with method
me?.walk()

// Optional Chaining with property with nil coalescing operator
me?.name ?? "Default Name"

let url:URL? = URL(string: "https://api.pexels.com/v1/search?query=nature&per_page=1")

if let actualUrl = URL(string: "https://api.pexels.com/v1/search?query=nature&per_page=1") {
    
    // step 2, create the url request and pass in actualUrl
    
}
